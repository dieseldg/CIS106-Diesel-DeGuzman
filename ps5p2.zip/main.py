startva = int(input('Enter a start value'))
stopva = int(input('Enter a stop value'))
increment = int(input('Enter incremental value'))

while startva <= stopva:
  print(startva)
  startva = startva + increment