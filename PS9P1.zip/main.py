def cdiscount(qty,price,disc):
  total = float(qty) * float(price)
  dtotal = total * (1-disc)
  damt = total - dtotal
  return dtotal,total,damt
qty = float(input("Enter quantity"))
price = float(input("Enter price"))
disc = float(input("Enter discount amt. (.xx)"))
dtotal, total, damt = cdiscount(qty,price,disc)
disc2 = disc * 100
print('Total is $', total)
print('Discounted price is $', dtotal)
print('Discounted amount is $', damt)
print('Discount rate is %', disc2)
