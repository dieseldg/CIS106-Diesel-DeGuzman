count = 0
totalexam = 00.00

res = input('Would you like to calculate the average score? CASE SENSITIVE: Yes or No')

while res == "Yes":
  count = count + 1
  lastn = input('Enter student lastname')
  score1 = float(input('Enter score one'))
  score2 = float(input('Enter score two'))
  avg = (score1 + score2) / 2
  print (lastn, " has an average score of ", avg)
  totalexam = totalexam + score1
  res = input('Would you like to continue? ( Yes or no)')

print ('Number of students: ', count)