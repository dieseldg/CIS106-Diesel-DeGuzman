#Prompt the user to repeatedly to do the program( input (Yes or No)). If they response Yes go into the loop and prompt the user for last name and miles from downtown Chicago. Write a function to compute the train ticket price. Pass to the function the miles from down town Chicago and determine the ticket price. Return the ticket price. Sum price of all tickets. 

res = input('Would you like to continue? (Yes or No) Case Sensitive')
tiksum = 00.00

while res == "Yes":
  lastn = input('Enter last name')
  milesdt = float(input('Enter miles from downtown Chicago'))
  def tikprice2(milesdt):
    if milesdt >= 30:
      tikprice = 12.00
    elif milesdt >=20 and milesdt <= 29:
      tikprice = 10.00
    elif milesdt >= 10 and milesdt <= 19:
      tikprice = 8.00
    else:
      tikprice =  5.00
    return tikprice
  tikprice = tikprice2(milesdt)
  print('Ticket price is $ ', tikprice)
  tiksum = tiksum + tikprice
  print ('Ticket sum is $ ', tiksum)
  res = input('Would you like to continue again? ( Yes or No) Case Sensitive')

print ('Ticket sum is $ ', tiksum)

