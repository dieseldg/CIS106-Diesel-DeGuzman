# connect to the file
f = open("p3.txt", "r")
lastname = f.readline()
btotal = 0.0


while lastname != "":
  salary = float(f.readline())
  if salary >= 100000.00:
     brate = .20
  if salary >= 50000 and salary < 100000:
      brate = .15
  else:
    brate = .10
  bonus = brate * salary
  print(lastname, " salary is ", salary, " & bonus rate is ", brate)
  lastname = f.readline()
  print ('Bonus is ', bonus)
  btotal = btotal + bonus
print('Sum of all bonuses is ', btotal)

 





