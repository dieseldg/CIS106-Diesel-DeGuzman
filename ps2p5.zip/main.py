ItemPrice = float(input("Item price is"))
DiscountPct = float(input("Discount percent in Decimal Form is"))

DiscountAmt = (DiscountPct * 100)

DiscountPrice = ItemPrice - DiscountAmt

print('Discounted price is: $', DiscountPrice)
print('Discount amount is:  $', DiscountAmt)