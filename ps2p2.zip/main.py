LastName = input("Last name is")
Hours = float(input("Hours is"))
PayRate = float(input("Pay rate is"))

GrossPay = (Hours*PayRate)

print('Last name is ', LastName)
print('Gross pay is ', GrossPay)