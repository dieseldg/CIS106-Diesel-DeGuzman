f = open("p5.txt", "r")

n = 0
totalt = 0

lastn = f.readline()

while lastn != "":
  discode = f.readline()
  credtake = float(f.readline())

  if discode == 'I':
    costcred = 250
  else:
    costcred = 500
  tuition = costcred * credtake

  totalt = totalt + tuition
  n = n + 1

  print("Student last name is ", lastn)
  print("Credits taken is ", credtake)
  print('Tuition is ', tuition)

  lastn = f.readline()

f.close()
print ('Number of students is ', n)
print ('Total tuition is ', totalt)
  