Length = float(input("Length of rectangle is"))
Width = float(input("Width of rectangle is"))

Area = Length*Width
Circumference = (Length + Width) * 2

print('Area of rectangle is', Area)
print('Circumference of rectangle is', Circumference)