f = open("p4.txt", "r")
order = 0
totalsum = 0
avg = 0


item = f.readline()

while item != "":
  order = order + 1
  qty = float(f.readline())
  price = float(f.readline())
  extprice = qty * price
  print(item, "Quantity is ", qty, " Price is ", price, " Extended price is", extprice)
  totalsum = totalsum + extprice
  avg = avg + extprice
  item = f.readline()
print('Total sum of extended price is', totalsum)
print('Total orders is', order)
avgorder = avg / order
print('Average order is', avgorder)

