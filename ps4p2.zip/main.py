pnum = int(input('Enter part number'))
qty = float(input('Enter quantity'))

if pnum == 10 or pnum == 55:
  unitprice = 1.00
elif pnum == 99:
  unitprice = 2.00
elif pnum == 80 or pnum == 70:
  unitprice = 3.00
else:
  unitprice = 5.00

total = qty * unitprice

print('Part number is', pnum)
print('Unit price is ', unitprice)
print('Total is ', total)
