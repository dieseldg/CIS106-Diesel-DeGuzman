#The user will enter employee last name, salary and job level (as noted below). Use the job level to determine the bonus rate. Then compute bonus to be salary times bonus rate. Display employee last name and bonus. 

lastn = input('Enter last name')
salary = float(input('Enter salary'))
joblvl = float(input('Enter job lvl'))

if joblvl >= 10:
  brate = .25
elif joblvl >= 5 and joblvl <= 9:
  brate = .20
else:
  brate = .10

bonus = salary * brate

print('Last name is', lastn)
print('Bonus rate is', brate)
print('Bonus is', bonus)
