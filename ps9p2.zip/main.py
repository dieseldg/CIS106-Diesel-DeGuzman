lastn = input('Enter student last name')
ex1 = float(input('Enter exam score 1'))
ex2 = float(input('Enter exam score 2'))
ex3 = float(input('Enter exam score 3'))

def exavg(ex1,ex2,ex3):
  savg = (ex1 + ex2 + ex3) / 3
  stotal = (ex1 + ex2 + ex3)
  return savg,stotal
savg,stotal = exavg(ex1,ex2,ex3)
print('Last name is ', lastn)
print('Student exam average is ', savg)
print('Student total is ',stotal)