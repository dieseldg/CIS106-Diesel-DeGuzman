lastn = input('Enter salesperson lastname')
sales = float(input('Enter $ of sales'))

def comission(sales):
  if sales >= 100000.00:
    com1 = .10
    scom = sales * com1
  elif sales <= 100000.00:
    com2 = .05
    scom = sales * com2
  target = sales * 1.05
  return scom, target

scom,target = comission(sales)

print('Salesperon last name is ', lastn)
print('Sales $ is', sales)
print('Comission is $', scom)
print('Next year target is', target)
  