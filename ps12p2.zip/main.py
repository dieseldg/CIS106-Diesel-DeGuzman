class Student:

  def __init__(self,first,last,dcode,credits):
    self.first = first
    self.last = last
    self.dcode = dcode
    self.credits = credits
  
  def tuition(self,chour):
    if self.dcode == "I":
      chour = 250.00
    elif self.dcode == "O":
      chour = 500.00
    else:
      t = chour * self.credits
    return t

s1 = Student('Bob','Jones','I',15)

print(s1.first)
print(s1.last)
print(s1.dcode)
print(s1.credits)
print(s1.t())



