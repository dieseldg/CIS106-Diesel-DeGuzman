# Enter the number of books to order and cost per book. If the order total is over $50.00 shipping is free. If the order total is $50.00 or under charge $25 shipping. Display the order total and shipping charge (note 0 should display for a free shipping charge). 

nbooks = float(input("enter number of books to order"))
cbooks = float(input("enter cost per book"))
total = nbooks * cbooks
if total <= 50:
  shipcharge = 25
else:
  shipcharge = 0

print('shipping charge is',shipcharge)
print("total is", total)