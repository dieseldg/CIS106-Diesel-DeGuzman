count = 0
thesum = 0
avgpay = 0

res = input('Would you like to continue? (Yes or No) Case Sensitive')



while res == 'Yes':
  count = count + 1
  lastname = input('Enter Employee Last Name')
  hrwork = float(input('Enter Hours Worked'))
  ratepay = float(input('Enter rate of pay'))
  grosspay = hrwork * ratepay
  if hrwork >= 40:
    hrwork = (hrwork * ratepay * 1.5)
    grosspay = hrwork
  print ('Employee last name is', lastname, "and grosspay is", grosspay)
  thesum = thesum + grosspay
  res = input('Would you like to continue again? ( Yes or No) Case Sensitive')
  avgpay = avgpay + grosspay / count

print('Employee count is ', count)
print('Employee total sum is ', thesum)
print('Average pay is ', avgpay)