#    5. Prompt the user to repeatedly to do the program( input (Yes or No)). If they response Yes go into the loop and prompt the user for county and market value of a home. Write a function to compute the assessed value. Pass to the function the county and market value. The function will determine the assessed value percent then compute and return the assessed value. (Multiple the market value by assessed value percent. Sum and display all market values and assessed values. 

res = input('Would you like to continue? (Yes or No) Case Sensitive')
mktvalsum = 0

while res == "Yes":
  county = input('Enter county')
  mktval = float(input('Enter market value'))
  def assessedval2(county,mktval):
    if county == "Cook":
      avp = 0.90
    elif county == "DuPage":
      avp = 0.80
    elif county == "McHenry":
      avp = 0.75
    elif county == "Kane":
      avp = 0.60
    else:
      avp = 0.70
    assessedval = mktval * avp
    return assessedval
  assessedval = assessedval2(county,mktval)
  mktvalsum = mktvalsum + assessedval
  print('Market value is $ ',mktval)
  print('Assesed value is $ ', assessedval)
  print('Total sum is $ ',mktvalsum)
  res = input('Would you like to continue again? ( Yes or No) Case Sensitive')
  
print('Total sum is $ ',mktvalsum)
  