# The input to the problem is quantity of widgets. Your program should determine the price to charge based on the schedule below. Calculate the extended price (quantity x price). Calculate tax at 7%.  Display the extended price, tax amount and total. 
qty = float(input('Enter quantity of widgets'))

if qty > 10000:
  price = 10
if qty > 5000:
  price = 20
if qty < 5000:
  price = 30

extp = qty * price
tax = extp * .07
total = extp + tax

print('Extended price is ', extp)
print('Tax is ', tax)
print('Total is', total)