response = input("Do you want to do this again? (Yes or No) ")

def displayname(lastname,score):
  l = len(lastname)
  sindex = -1
  for y in range(0,l,1):
    if lastname[y] == sname:
      sindex = y

  return sindex


x = open("battavg.txt","r")

#arrays defined below
lastname = []
score = []

lastn = x.readline()

#lastname = string val,
while lastn != "":
  lastname.append(str(lastn).rstrip("\n"))
  l = float(x.readline())
  score.append(l)
  lastn = x.readline()

while response == "Yes":
  sname = input("Enter name to look up")
  i = displayname(lastname,score)
  if i == -1:
    print (sname,"'s name was not found'")
  else:
    print (lastname[i], " has a battling avg of ", score[i])

#lastname = string val,

displayname(lastname,score)

