def highscore(lastname,score):
  z = len(lastname)
  highscore = 0
  lowscore = 100
  for y in range (0,z,1):
    if float(score[y]) > float(highscore):
      hiis = y
      highscore = score[y]
    
    if float(score[y]) < float(lowscore):
      liis = y
      lowscore = score[y]
  print("Highest score", lastname[hiis], score[hiis])
  print("Lowest score", lastname[liis], score[liis])

x = open("arrlastnsal.txt","r")

#arrays defined below
lastname = []
score = []

lastn = x.readline()

#lastname = string val,
while lastn != "":
  lastname.append(str(lastn).rstrip("\n"))
  l = float(x.readline())
  score.append(l)
  lastn = x.readline()

highscore(lastname,score)