def milespergallon(milestrav,galused):
  mpg = float(milestrav) / float(galused)
  
  return mpg

descity = input('Enter destination city')
milestrav = float(input('Enter miles traveled'))
galused = float(input('Enter gallons used'))

mpg = milespergallon(milestrav,galused)
galcost = 2.50

def tripcost(galused,galcost):
  cost = galused * galcost

  return cost

cost = tripcost(galused, galcost)

print('Destination city is ', descity)
print('Miles traveled is ', milestrav)
print('Miles per gallon is ', mpg)
print('Cost of gas is ', cost)