#     2. The program asks the user for an item and quantity. Determine the unit price of the item based on the chart below. Compute the extended price to be quantity x unit price. Display the item, unit price and extended price.  Item			Unit Price			$10.00B			$20.00

item = input('enter item A or B')
qty = float(input('enter quantity'))

if item == "A":
  up = 10
else:
  up = 20

extprice = qty * up

print('item a or b is ', item)
print('unit price is', up)
print('extended price is ', extprice)