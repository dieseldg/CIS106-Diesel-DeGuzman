def displayname(lastname,salary):
  z = len(lastname)
  print('Array elements #', z)
  print('Array list in order')
  for y in range (0,z,1):
    print(lastname[y],salary[y])
  print('Array list in reverse order')
  for y in range (z-1, -1, -1):
    print(lastname[y],salary[y])

x = open("arrlastnsal.txt","r")

#arrays defined below
lastname = []
salary = []

lastn = x.readline()


#lastname = string val,
while lastn != "":
  lastname.append(str(lastn).rstrip("\n"))
  l = float(x.readline())
  salary.append(l)
  lastn = x.readline()


displayname(lastname,salary)
