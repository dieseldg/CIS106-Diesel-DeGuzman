LastName = input("Last name is")
CredTake = float(input("Credits taken is"))

Tuition = CredTake * 250
LabFee = 100

TotalTuition = Tuition + LabFee

print('Last name is', LastName)
print('Total tuition is', TotalTuition)