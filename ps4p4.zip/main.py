#Allow the user to enter number of concert tickets. The price per ticket depends on the volume (see below). Display the number of tickets, price per ticket and the total cost (number of tickets x Price Per Ticket). 

ctik = float(input('Enter # of concert tickets'))

if ctik >= 25:
  priceper = 50
if ctik >= 10 and ctik <= 24:
  priceper = 60
if ctik >= 5 and ctik <=9:
  priceper = 70
if ctik < 5:
  priceper = 75

total = ctik * priceper

print ('Number of concert ticket is ', ctik)
print ('Price per ticket is ', priceper)
print ('Total is ', total)
