# (2 x length x width (floor and ceiling) + 2 x length x height (2 of the walls) + 2 x width x height (the other 2 walls).

res = input('Would you like to continue? (Yes or No) Case Sensitive')

while res == "Yes":
  length = float(input('Enter length'))
  width = float(input('Enter width'))
  height = float(input('Enter height'))
  def sqfootage2(length,width,height):
    sqfootage= (2 * length * width) + (2 * length * height) + (2 * width * height)
    return sqfootage
  sqfootage = sqfootage2(length,width,height)
  galpaint = 50
  ngalneed = sqfootage / galpaint
  print('Number of gallons needed to paint room is ', ngalneed)
  res = input('Would you like to continue again? ( Yes or No) Case Sensitive')

