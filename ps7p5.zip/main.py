lastn = input('Enter student last name')
credhour = float(input('Enter credit hours'))
discode = input('Enter district code (I or O)')

def tuitionowe2(credhour,discode):
  if discode == "I":
    credprice = 250.00
  if discode == "O":
    credprice = 550.00
  tuitionowe = credprice * credhour
  return tuitionowe

tuitionowe = tuitionowe2(credhour,discode)

print('Student last name is ', lastn)
print('Tuition owed by student is ', tuitionowe)