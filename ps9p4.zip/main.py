lastn = input('Enter bowler last name')
g1 = float(input('Enter game score 1'))
g2 = float(input('Enter game score 2'))
g3 = float(input('Enter game score 3'))
h1 = float(input('Enter bowling handicap'))

def ascore(g1,g2,g3,h1):
  avg = (g1+g2+g3) / 3
  avg2 = (g1+g2+g3+h1) / 4
  return avg,avg2

avg, avg2 = ascore(g1,g2,g3,h1)

print('Bowler last name is ', lastn)
print('Average score is ', avg)
print('Average score with handicap is', avg2)
