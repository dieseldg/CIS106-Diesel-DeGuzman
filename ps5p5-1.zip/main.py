number_of_orders = 0
totalsum = 0

run_program = input('Do you want to run the program (Yes/No): ')

while run_program == 'Yes':
    quantity = float(input('Enter your quantity here: '))
    price_of_item = float(input('Enter the price of item here: '))
    sub_total = quantity * price_of_item

    if sub_total > 1000:
        discount = sub_total * 0.25
    else:
        discount = sub_total * 0.10

    total = sub_total - discount
    totalsum = totalsum + discount
    number_of_orders = number_of_orders + 1

    print('The extended price is: ', sub_total)
    print('The discount price is: ', discount)
    print('The sum of the price is: ', total)

    run_program = input('Do you want to run program again? (Yes/No): ')

print('Total discount: ', totalsum)

averg = totalsum / number_of_orders

print('Average is: ', averg)