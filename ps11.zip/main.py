def list (dlist1):
  r = int(input('How many numbers do you want for the list?'))
  for r in range (0,r,1):
    s = int(input('Enter integer(s)'))
    dlist1.append(s)
  return dlist1
def displaylist(dlist1):
  for item in dlist1:
      print(item)

dlist1 = []
dlist1 = list(dlist1)
displaylist(dlist1)
print(dlist1)


# 0 DEFINES FIRST NUMBER, which means the first position in the list/array
dlist1.insert(0,99)
print(dlist1)

#Since we want to replace 99 with 100, we replace the first position as its in the current position of 0.
dlist1[0] = 100
print(dlist1)

#We want to add the second list to the first, but extend the first list with the second
dlist2 = [500,600,700,800,900]
dlist1.extend(dlist2)
print(dlist1)

#We want to remove 800 off the second list
dlist1.remove(800)
print(dlist1)

#Removing 3rd item off first list which is at the SECOND index
dlist1.pop(2)
print(dlist1)

#List of grades
grades = ["A", "B", "C", "A", "A", "C"]

#Print count of A's
print("Count of A's in the list of grades", grades.count("A"))

#Display the index (position) of the first B grade.
print("Index of first B in the grades", grades.count("B"))

#Look for grade of F in the grades list. Display a message that F is not in the list. (Do not let the code generate an error). 
if grades.index != ('F'):
  print("No F was found in the list")

#Clear (but do not delete) the second list of integers. Display the list. 
dlist2.clear()
print (dlist2)

#Delete the second list. Try to display it. (should get an error because the list no longer exists.
del dlist2[:]
print (dlist2)

#Create a list of players in this order (“Rizzo”, “Davis”, “Baez”, “Happ”, “Bryan”)
players = ["Rizzo", "Davis", "Baez", "Happ", "Bryan"]

#Sort the list of players. Display the sorted list. 
players.sort()
print(players)

#Make a copy of the list of players called players2. Display players2.
players2 = ["Rizzo", "Davis", "Baez", "Happ", "Bryan"]
print(players2)

#Reverse the order of players2. Display players, then display players2. 
players2.reverse()
print(players2)