startva = 1
stopva = 25
increment = 2

while startva <= stopva:
  print(startva)
  startva = startva + increment