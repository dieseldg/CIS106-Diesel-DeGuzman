total = 0
tax = 0


qty = float(input("Enter quantity of item"))
price = float(input("Enter price of item"))

def comptotal(qty, price):
  global total
  total = float(qty) * float(price)
  global tax
  tax = total * 0.07
  return total, tax
# GLOBAL
comptotal(qty,price)

print("total is $", total)
print("tax is   $", tax)