class Employee:

  def __init__(self,first,last,salary):
    self.first = first
    self.last = last
    self.salary = salary
    self.email = first + '.' + last + '@company.com'

  def bonus(self,rate):
    b1 = float(rate) * float(self.salary)
    return b1
e1 = Employee('John','Doe',50000.00)

print(e1.email)
print(e1.first)
print(e1.last)
print(e1.salary)
print(e1.bonus(.25))
print(e1.bonus(.15))
