while True:
    p = float(input("Enter Principle"))
    ps = p
    r = float(input("Enter interest rate"))
    print('Year','Beginning Balance','Ending Balance')
    for count in range(1, 6, 1):
        i = p * r
        eb = p + i
        print (count,'   ', p,'      ', format(eb,'10'))
        p = eb
    tint = eb - ps
    print('Total Interest is: ', tint)
    res = input('Would you like to calculate again? ( Yes or No)')
    if res == 'No':
        break