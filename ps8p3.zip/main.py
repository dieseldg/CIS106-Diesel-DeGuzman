msrpsum = 0

res = input('Would you like to continue? (Yes or No) Case Sensitive')

while res == "Yes":
  make = input("Enter make")
  model = input("Enter model")
  evcode = input("Electric Vehicle code (Y or N)")
  msrp = float(input('Enter msrp (sticker price) of vehicle'))
  def outdoor2(msrp,make,model,evcode):
    if make == "Honda" and model == "Accord":
      pctoff = .10
    elif make == "Toyota" and model == "Rav4":
      pctoff = .15
    elif evcode == "Y":
      pctoff = .30
    else:
      pctoff = .05
    outdoornotax = msrp*(1-pctoff)
    outdoor = outdoornotax * 1.07
    return outdoor
  outdoor = outdoor2(msrp,make,model,evcode)
  print('Total is $ ', outdoor)
  msrpsum = msrpsum + outdoor
  print('Msrp sum is $ ', msrpsum)
  res = input('Would you like to continue again? ( Yes or No) Case Sensitive')

    
