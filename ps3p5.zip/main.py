LastName = input('Enter Last Name')
GrossPay = float(input('Enter your gross pay/income'))
Dependents = input('Enter your number of dependents')

AdjGrossIncome = GrossPay - 12000 * float(Dependents)

if AdjGrossIncome > 50000:
  tax = AdjGrossIncome * .2
else:
  tax = AdjGrossIncome * .1


  if tax < 0:
    tax = 100


print("Last name is ", LastName)
print("Gross pay is ", GrossPay)
print("Number of dependents is ", Dependents)
print("Adjusted Gross Incoeme is ", AdjGrossIncome)
print("Income tax is ", tax)