#Enter a principle amount of a CD and year to maturity of CD. Determine the interest rate based on the amount of the principle and maturity (see below). Calculate first year interest (principle x interest rate). Display principle, interest rate and the interest amount for first year. 

principle = float(input('Enter principle amount'))
matDate = input('Enter maturity date')

if principle > 100000 and matDate == 5:
  intRate = 0.06
elif principle > 50000 and matDate == 10 and principle < 100000:
  intRate = 0.05
elif principle > 50000 and matDate == 5 and principle < 100000:
  intRate = 0.04
else:
  intRate = 0.02

fyint = principle * intRate



print('Principle is ', principle)
print('Interest rate is', intRate)
print('First year interest is ', fyint)