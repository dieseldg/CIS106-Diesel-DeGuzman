res = input('Would you like to continue? (Yes or No) Case Sensitive')

while res == "Yes":
  lastn = input('Enter lastname')
  month = input('Enter month (First three letters lowercase)')
  sales = float(input('Enter sales'))
  def nextmonthforecast(month,sales):
    if month == "jan" or "feb" or "mar":
     fpct = .10
    elif month == "apr" or "may" or "jun":
     fpct = .15
    elif month == "jul" or "aug" or "sep":
      fpct = .20
    elif month == "oct" or "nov" or "dec":
      fpct = .25
    nextmonthsales = sales * (1 + fpct)
    return nextmonthsales

  nextmonthsales = nextmonthforecast(month,sales)
  print('Next month sales is', nextmonthsales)
  res = input('Would you like to continue again? ( Yes or No) Case Sensitive')





