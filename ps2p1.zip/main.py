Quantity = float(input("Quantity"))
PricePerUnit = float(input("PricePerUnit"))
ExtendedPrice = (Quantity * PricePerUnit)

print('Extended price is ', ExtendedPrice)