lastn = input('Enter last name')
jobcode = input('Enter job code (L, A, J)')
hourswork = float(input('Enter hours worked'))

def payrate2(jobcode):
  if jobcode == "L":
    payrate = 25
  if jobcode == "A":
    payrate = 30
  if jobcode == "J":
    payrate = 50
  return payrate
payrate = payrate2(jobcode)

if hourswork >= 40:
  payrate = payrate * 1.50

def grosspay2(hourswork,payrate):
  grosspay = hourswork * payrate
  return grosspay

grosspay = grosspay2(hourswork,payrate)

print('Last name is ', lastn)
print('Grosspay is ', grosspay)