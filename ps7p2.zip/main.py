def battleavg(nhits,bats):
  bavg = float(bats) / float(nhits)
  
  return bavg

lastn = input('Enter lastname')
nhits = float(input('Enter number of hits'))
bats = float(input('Enter number of bats'))

bavg = battleavg(nhits,bats)

print('Last name is ', lastn)
print('Batting average is ', bavg)