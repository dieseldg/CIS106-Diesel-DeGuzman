numbers = 20
n1, n2 =  1,1
count = 0

while count < numbers:
       print(n1)
       nth = n1 + n2
       n1 = n2
       n2 = nth
       count += 1