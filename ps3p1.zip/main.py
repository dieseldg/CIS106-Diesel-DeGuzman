# Allow a user to enter a quantity of an item.  If the quantity is greater than or equal to 1000, the unit price should be $3.00. For quantities under 1000 the unit price is $5.00. Compute extended price to be quantity x unit price. Compute tax to be 7% of the extended price. The total is computed as extended price plus the tax. Display the quantity, unit price, extended price, tax and total. 

qty = float(input("Enter quantity"))

if qty >= 1000:
  up = 3.00
else:
  up = 5.00

extprice = qty * up
tax = extprice * 0.07
total = extprice + tax

print('quanity is', qty)
print('unit price is', up)
print('extended price is', extprice)
print('tax is', tax)
print('total is', total)
